class Section < ApplicationRecord
  include Leafable
end
