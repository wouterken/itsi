---
title: Welcome
---
# Welcome to Writebook

Thanks for downloading Writebook. 

Writebook is remarkably simple software that allows you to publish text and pictures in a simple, browsable online book format. It's independent publishing for everyone.

Use it for everything from an instruction manual (like this one!), to employee handbooks, internal technical runbooks, graphic novels, collections of short stories, poetry, blog posts, novels, or family history. Put it all into Writebook and instantly publish to the web.

And because you host it yourself, you own all your own data. With no limits on readers or writers, you can create as many books as you like. You're in control.

In the pages that follow we'll help you get started with Writebook and show you how it all works. 

We can't wait to see what you make with it!
